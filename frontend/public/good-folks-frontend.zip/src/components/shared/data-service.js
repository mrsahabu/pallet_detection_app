import axios from "axios";

export default class ApiService {
  apiBaseURL =
    "https://05f1-2400-adc5-472-6e00-84c1-20c7-129f-d09f.ngrok-free.app/";

  getAccessToken() {
    const token = localStorage.getItem("tokens");
    if (token?.access_token) {
      return token?.access_token;
    } else {
      return false;
    }
  }

  getRefreshToken() {
    const token = localStorage.getItem("refresh");
    if (token) {
      return token;
    } else {
      return false;
    }
  }

  getAdmin() {
    const token = localStorage.getItem("admin");
    if (token?.refresh_token) {
      return token?.refresh_token;
    } else {
      return false;
    }
  }

  logIn = (payload) => {
    const headers = {
      "Content-Type": "multipart/form-data",
    };
    const formData = new FormData();
    for (const key in payload) {
      if (payload.hasOwnProperty(key)) {
        formData.append(key, payload[key]);
      }
    }
    return axios.post(this.apiBaseURL + "auth/token", payload, headers);
  };

  logOut() {
    const headers = {
      Authorization: `Bearer ${this.getAccessToken()}`,
    };
    const refresh = this.getRefreshToken();
    return axios.post(this.apiBaseURL + "auth/logout/", { refresh }, headers);
  }

  refreshToken() {
    const refresh = this.getRefreshToken();
    return axios.post(this.apiBaseURL + "auth/login/refresh/", { refresh });
  }

  registerUser(data) {
    return axios.post(this.apiBaseURL + "users/", data);
  }

  uploadImages(images) {
    const formData = new FormData();

    images.forEach((image, index) => {
      if (image.file) {
        // If it's a file, append it directly
        formData.append(`image${index}`, image.file);
      } else if (image.base64) {
        // If it's a base64 string, convert to Blob and append
        const byteString = atob(image.base64.split(",")[1]);
        const mimeString = image.base64
          .split(",")[0]
          .split(":")[1]
          .split(";")[0];
        const ab = new ArrayBuffer(byteString.length);
        const ia = new Uint8Array(ab);
        for (let i = 0; i < byteString.length; i++) {
          ia[i] = byteString.charCodeAt(i);
        }
        const blob = new Blob([ab], { type: mimeString });
        formData.append(`image${index}`, blob);
      }
    });

    const headers = {
      "Content-Type": "multipart/form-data",
      Authorization: `Bearer ${this.getAccessToken()}`,
    };
    return axios.post(
      this.apiBaseURL +
        "pallet_detection/image_upload?email_to=st747809%40gmail.com",
      formData,
      headers
    );
  }

  getALLVideos() {
    const headers = {
      Authorization: `Bearer ${this.getAccessToken()}`,
    };
    return axios.post("users/get_all_videos_details", {}, headers);
  }
}
